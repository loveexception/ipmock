package selenium2;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import mappers.is.web.bmw.sql.LoginsExtendViewMapper;
import mappers.is.web.bmw.sql.LoginsMapper;
import mappers.is.web.bmw.sql.PersonsMapper;
import mappers.is.web.bmw.sql.SubtopicsMapper;
import mappers.is.web.bmw.sql.TopicsMapper;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import utils.Constant;
import utils.ProxyUtils;

import com.is.web.bmw.entity.ProxyResponse;
import com.is.web.bmw.entity.sql.entity.Persons;
import com.is.web.bmw.entity.sql.entity.Subtopics;
import com.is.web.bmw.entity.sql.entity.Topics;
import com.is.web.bmw.entity.sql.entityenum.LoginsStauts;
import com.is.web.bmw.entity.sql.entityenum.SubtopicsStatus;
import com.is.web.bmw.entity.sql.extend.LoginsExtend;

public class SeleniumMyBmw {
	private static String resource = "mybatis-config.xml";
	
	WebDriver driver ;
	
	static Logger logger = LogManager.getLogger(SeleniumMyBmw.class.getName());
	
	List<ProxyResponse> responseList = ProxyUtils.getProxyList();
	
	Date beginTime;
	
	public static void main(String[] args) {
		
		if(null==args){
			System.setProperty("webdriver.chrome.driver",Constant.DRIVERPATH);
		}else{
			System.setProperty("webdriver.chrome.driver",args[0]);
		}
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
			SqlSession session = sqlSessionFactory.openSession();
			SeleniumMyBmw slmb = new SeleniumMyBmw();
			slmb.login(session);
			slmb.openForumPage(session);
			slmb.faveForumPage(session);
			slmb.replyForum(session);
			session.close();
		} catch (Exception e) {
			logger.error("初始化操作失败：{}",e.getLocalizedMessage());
		} finally{
			
		}
    }

	/**
	 * 立刻关闭
	 * @param driver
	 */
	public void webQuit(WebDriver driver){
		Date endTime = new Date();
		logger.info("操作完成：用时[{}秒],开始[{}]，结束[{}]",(endTime.getTime() - beginTime.getTime()) / 1000,beginTime,endTime);
		driver.quit();
	}

	/**
	 * 在指定时间后关闭
	 * @param driver
	 * @param keep
	 */
	public void webQuit(WebDriver driver,long keep){
		Date endTime = new Date();
		logger.info("操作完成：用时[{}秒],开始[{}]，结束[{}]",(endTime.getTime() - beginTime.getTime()) / 1000,beginTime,endTime);
		try {
			Thread.sleep(keep);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.quit();
	}
	
	/**
	 * 设定访问代理
	 * @return
	 */
	public WebDriver checkProxy(){
		beginTime = new Date();
		//随机找个代理
		Random random = new Random();
		int s = random.nextInt(responseList.size())%(responseList.size()+1);
		
		String proxyIpAndPort= responseList.get(s).getIp().concat(":").concat(responseList.get(s).getPort());
		logger.info("使用代理地址为：[{}]", proxyIpAndPort);
		
		DesiredCapabilities cap = new DesiredCapabilities();
		Proxy proxy=new Proxy();
		proxy.setHttpProxy(proxyIpAndPort).setFtpProxy(proxyIpAndPort).setSslProxy(proxyIpAndPort);
		cap.setCapability(CapabilityType.ForSeleniumServer.AVOIDING_PROXY, true);
		cap.setCapability(CapabilityType.ForSeleniumServer.ONLY_PROXYING_SELENIUM_TRAFFIC, true);
		System.setProperty("http.nonProxyHosts", responseList.get(s).getIp());
		cap.setCapability(CapabilityType.PROXY, proxy);
//		driver = new ChromeDriver(cap);
//		driver = new ChromeDriver();
		try {
			driver = new RemoteWebDriver(new URL("http://127.0.0.1:4444/wd/hub"), cap.chrome());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		return driver;
	}
	
	/**
	 * 登录任务
	 * @param session
	 */
	public void login(SqlSession session){
		LoginsExtendViewMapper loginMapper = session.getMapper(LoginsExtendViewMapper.class);
		Map<String, Object> compareCols = new HashMap<String, Object>();
		compareCols.put("planLessThan", new Date());
		LoginsExtend loginFilter = new LoginsExtend();
		loginFilter.setStauts(LoginsStauts.EV_1.enumVal);
		loginFilter.setCompareCols(compareCols);
		
		List<LoginsExtend> resultList = loginMapper.getAllLoginsBySearchWithJoin(loginFilter);
		for(int i=0;i<resultList.size();i++){
			LoginsExtend loginE = resultList.get(i);
			if(StringUtils.isEmpty(loginE.getPidName()) || 
					StringUtils.isBlank(loginE.getPidPassword())){
				logger.error("登录操作失败：登录信息为空,[{}]",loginE.getId());
			}else{
				logger.info("登录操作完成,任务ID：[{}]",loginE.getId());
				driver = checkProxy();
				driver.get(Constant.LOGIN_URL);
				
				WebElement elementPass = driver.findElement(By.id(Constant.LOGIN_PAGE_LOGINPASS_DOMID));
				elementPass.sendKeys(loginE.getPidPassword());
				
				WebElement element = driver.findElement(By.id(Constant.LOGIN_PAGE_LOGINID_DOMID));
				element.sendKeys(loginE.getPidName());
				element.submit();
				
				LoginsMapper loginM = session.getMapper(LoginsMapper.class);
				loginE.setStauts(LoginsStauts.EV_9.enumVal);
				loginE.setSend(new Date());
				loginM.updLoginsByPrimaryKey(loginE);
				session.commit();
				
				webQuit(driver);

			}
		}

	}
	
	/**
	 * 打开帖子
	 * @param loginId
	 * @param password
	 * @param forumId
	 */
	public void openForumPage(SqlSession session){
		TopicsMapper topicMapper = session.getMapper(TopicsMapper.class);
		LoginsExtendViewMapper loginMapper = session.getMapper(LoginsExtendViewMapper.class);
		
		int userCount = loginMapper.getCountForPageWithJoin(new LoginsExtend());	//系统用户数
		List<Map> result = topicMapper.getResultForSelectParam(" id,name,readed,readedplan,liked,likedplan,collected,collectedplan,oldid,content from t_topics where readedplan>readed limit 0,10");
		for(int i=0;i<result.size();i++){
			Map topics = result.get(i);
			int read = (int) topics.get("readed");
			int readPlan = (int) topics.get("readedplan");
			for(int j=read;j<readPlan;j++){
				//随机找个用户
				Random random = new Random();
				int s = random.nextInt(userCount)%(userCount+1);
				List<LoginsExtend> resultList = loginMapper.getAllLoginsByPageWithJoin(s, 1, new LoginsExtend());
				LoginsExtend loginE = resultList.get(0);
				
				logger.info("登录操作完成,任务ID：[{}]",topics.get("id").toString());
				driver = checkProxy();
				driver.get(Constant.LOGIN_URL);
				
				WebElement elementPass = driver.findElement(By.id(Constant.LOGIN_PAGE_LOGINPASS_DOMID));
				elementPass.sendKeys(loginE.getPidPassword());
				
				WebElement element = driver.findElement(By.id(Constant.LOGIN_PAGE_LOGINID_DOMID));
				element.sendKeys(loginE.getPidName());
				element.submit();
				
				driver.get(Constant.FORUM_URL.replace("#forumId#", topics.get("oldid").toString()));
				
				webQuit(driver,1000 * 10);
				
			}
			Topics topicsUpd = new Topics();
			topicsUpd.setId((Integer) topics.get("id"));
			topicsUpd.setReadedplan(readPlan);
			topicMapper.updTopicsByPrimaryKey(topicsUpd);
			session.commit();
		}
	}

	/**
	 * 打开帖子，并点赞
	 * @param loginId
	 * @param password
	 * @param forumId
	 */
	public void faveForumPage(SqlSession session){
		TopicsMapper topicMapper = session.getMapper(TopicsMapper.class);
		LoginsExtendViewMapper loginMapper = session.getMapper(LoginsExtendViewMapper.class);
		
		int userCount = loginMapper.getCountForPageWithJoin(new LoginsExtend());	//系统用户数
		List<Map> result = topicMapper.getResultForSelectParam(" id,name,readed,readedplan,liked,likedplan,collected,collectedplan,oldid,content from t_topics where likedplan>liked limit 0,10");
		for(int i=0;i<result.size();i++){
			Map topics = result.get(i);
			int liked = (int) topics.get("liked");
			int likedplan = (int) topics.get("likedplan");
			for(int j=liked;j<likedplan;j++){
				//随机找个用户
				Random random = new Random();
				int s = random.nextInt(userCount)%(userCount+1);
				List<LoginsExtend> resultList = loginMapper.getAllLoginsByPageWithJoin(s, 1, new LoginsExtend());
				LoginsExtend loginE = resultList.get(0);
				
				logger.info("登录操作完成,任务ID：[{}]",topics.get("id").toString());
				driver = checkProxy();
				driver.get(Constant.LOGIN_URL);
				
				WebElement elementPass = driver.findElement(By.id(Constant.LOGIN_PAGE_LOGINPASS_DOMID));
				elementPass.sendKeys(loginE.getPidPassword());
				
				WebElement element = driver.findElement(By.id(Constant.LOGIN_PAGE_LOGINID_DOMID));
				element.sendKeys(loginE.getPidName());
				element.submit();
				
				driver.get(Constant.FORUM_URL.replace("#forumId#", topics.get("oldid").toString()));
		
				List<WebElement> inputs = driver.findElements(By.xpath("//div[@id=\"p_btn\"]//a[@id=\"k_favorite\"]"));
				inputs.get(0).click();
				webQuit(driver);
				
			}
			Topics topicsUpd = new Topics();
			topicsUpd.setId((Integer) topics.get("id"));
			topicsUpd.setLikedplan(likedplan);
			topicMapper.updTopicsByPrimaryKey(topicsUpd);
			session.commit();
		}
	}
	
	/**
	 * 打开帖子，回帖
	 * @param loginId
	 * @param password
	 * @param forumId
	 * @param content
	 */
	public void replyForum(SqlSession session){
		SubtopicsMapper subtopicsMapper = session.getMapper(SubtopicsMapper.class);
		
		Subtopics subtopicsFilter = new Subtopics();
		Map<String, Object> compareCols = new HashMap<String, Object>();
		compareCols.put("planLessThan", new Date());
		subtopicsFilter.setStatus(LoginsStauts.EV_1.enumVal);
		subtopicsFilter.setCompareCols(compareCols);
		
		LoginsExtendViewMapper loginMapper = session.getMapper(LoginsExtendViewMapper.class);
		
		PersonsMapper personMapper = session.getMapper(PersonsMapper.class);
		TopicsMapper topicMapper = session.getMapper(TopicsMapper.class);

		int userCount = loginMapper.getCountForPageWithJoin(new LoginsExtend());	//系统用户数
		List<Subtopics> result = subtopicsMapper.getAllSubtopicsByPage(0, 20, subtopicsFilter);
		for(int i=0;i<result.size();i++){
			Subtopics subtopics = result.get(i);
			//随机找个用户
			Persons person = personMapper.getPersonsByPrimaryKey(new Persons(subtopics.getPid()));
			logger.info("用户登陆:{}-{}",person.getName() , person.getPassword());
			driver = checkProxy();
			driver.get(Constant.LOGIN_URL);
			
			WebElement elementPass = driver.findElement(By.id(Constant.LOGIN_PAGE_LOGINPASS_DOMID));
			elementPass.sendKeys(person.getPassword());
			
			WebElement element = driver.findElement(By.id(Constant.LOGIN_PAGE_LOGINID_DOMID));
			element.sendKeys(person.getName());
			element.submit();
			
			
			Topics topic = new Topics();
			topic.setId(subtopics.getTid());
			topic = topicMapper.getTopicsByPrimaryKey(topic);
			logger.info("登录操作完成,任务ID：[{}]",subtopics);

			driver.get(Constant.FORUM_URL.replace("#forumId#", topic.getOldid().toString()));
	
			List<WebElement> inputs = driver.findElements(By.xpath("//textarea[@id=\"fastpostmessage\"]"));
			WebElement elementInput = inputs.get(0);
			elementInput.sendKeys(subtopics.getContext());
			elementInput.submit();
			
			subtopics.setStatus(SubtopicsStatus.EV_9.enumVal);
			subtopicsMapper.updSubtopicsByPrimaryKey(subtopics);
			session.commit();
			webQuit(driver);
				
		}
	}
}
