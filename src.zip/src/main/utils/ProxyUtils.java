package utils;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.is.web.bmw.entity.ProxyResponse;

public class ProxyUtils {

	static Logger logger = LogManager.getLogger("RunningLog");
	
	public static List<ProxyResponse> getProxyList(){
		HttpClient httpclient = new DefaultHttpClient();
		StringBuffer sbParamer = new StringBuffer();
		sbParamer.append("http://dec.ip3366.net/api/?key=20170306100439929&getnum=30&filter=1&area=1&formats=2&proxytype=0");
		
		URI uri;
		try {
			uri = new URI(sbParamer.toString());
			HttpGet httpget = new HttpGet(uri);

			try {
				HttpResponse response;
				response = httpclient.execute(httpget);
				HttpEntity entity = response.getEntity();

				String postdata = IOUtils
						.toString(entity.getContent(), "utf-8");
//				postdata = "[{\"Ip\":\"103.40.151.90\",\"Port\":8080,\"Country\":\"\",\"FullAddres\":\"\",\"ProxyType\":0,\"Sec\":0,\"AnonymousType\":2}]";
//				logger.info("代理接口列表：[{}]",postdata);
				Gson gson = new Gson();
				List<ProxyResponse> responseList = gson.fromJson(postdata,
						new TypeToken<List<ProxyResponse>>() {
						}.getType());
//				System.out.println(responseList.get(0).getPort());
				return responseList;
			} catch (ClientProtocolException e) {
				logger.error(e.getMessage());
			} catch (IOException e) {
				logger.error(e.getMessage());
			} finally {
				httpget.releaseConnection();
			}
		} catch (URISyntaxException e1) {
			logger.error(e1.getMessage());
		}
		return null;
	}
}
