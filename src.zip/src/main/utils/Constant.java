package utils;

public class Constant {

	public static final String DRIVERPATH = "/Users/hanbing/workspace/java/chromedriver";  
	
	public static final String LOGIN_URL = "http://139.217.15.159/newbocc/member.php?mod=logging&action=login&referer=";
	public static final String LOGIN_PAGE_LOGINID_DOMID = "username";
	public static final String LOGIN_PAGE_LOGINPASS_DOMID = "password3";

	public static final String FORUM_URL = "http://139.217.15.159/newbocc/forum.php?mod=viewthread&tid=#forumId#&extra=page%3D1";

	public static final String FORUM_PAGE_FAVORITE_DOMID = "k_favorite";

//	public static final String DRIVERPATH = PropertiesUtil.getStringByKey("webdriver.chrome.driver");  
//	
//	public static final String LOGIN_URL = PropertiesUtil.getStringByKey("page.login.url");
//	public static final String LOGIN_PAGE_LOGINID_DOMID = PropertiesUtil.getStringByKey("page.login.input.login.id");
//	public static final String LOGIN_PAGE_LOGINPASS_DOMID = PropertiesUtil.getStringByKey("page.login.input.login.password");
//	
//	public static final String FORUM_URL = PropertiesUtil.getStringByKey("page.forum.url");
//	
//	public static final String FORUM_PAGE_FAVORITE_DOMID = PropertiesUtil.getStringByKey("page.forum.favorite.id");
	
}
